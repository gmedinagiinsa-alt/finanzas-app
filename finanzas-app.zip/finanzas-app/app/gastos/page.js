'use client';
import React, { useState, useEffect } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { CATEGORIES, fmt } from '@/lib/constants';
import { Card, Input } from '@/components/ui';

export default function GastosPage() {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ category: CATEGORIES[0], amount: '', date: new Date().toISOString().slice(0, 10), description: '' });

  async function load() {
    const { data } = await supabase.from('expenses').select('*').order('date', { ascending: false });
    setExpenses(data || []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function submit() {
    if (!form.amount) return;
    await supabase.from('expenses').insert(form);
    setForm({ category: CATEGORIES[0], amount: '', date: new Date().toISOString().slice(0, 10), description: '' });
    setShowForm(false);
    load();
  }

  async function remove(id) {
    await supabase.from('expenses').delete().eq('id', id);
    load();
  }

  const total = expenses.reduce((s, e) => s + (Number(e.amount) || 0), 0);

  if (loading) return <p className="text-sm text-slate-400 text-center py-16">Cargando…</p>;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl text-slate-900">Gastos</h1>
          <p className="text-sm text-slate-500 mt-1">Total registrado: <span className="font-semibold text-rose-600">{fmt(total)}</span></p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
          <Plus size={20} />
        </button>
      </div>

      {showForm && (
        <Card className="space-y-3">
          <div>
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Categoría</label>
            <select
              value={form.category}
              onChange={e => setForm({ ...form, category: e.target.value })}
              className="mt-1 w-full border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-indigo-400"
            >
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Monto" type="number" value={form.amount} onChange={v => setForm({ ...form, amount: v })} />
            <Input label="Fecha" type="date" value={form.date} onChange={v => setForm({ ...form, date: v })} />
          </div>
          <Input label="Descripción (opcional)" value={form.description} onChange={v => setForm({ ...form, description: v })} />
          <button onClick={submit} className="w-full py-2.5 rounded-xl bg-indigo-600 text-white text-sm font-medium">Agregar gasto</button>
        </Card>
      )}

      <div className="space-y-2">
        {expenses.length === 0 && <p className="text-sm text-slate-400 text-center py-8">Aún no has registrado gastos.</p>}
        {expenses.map(e => (
          <Card key={e.id} className="flex items-center justify-between py-3">
            <div>
              <div className="font-medium text-sm text-slate-800">{e.category}</div>
              <div className="text-xs text-slate-400">{e.date}{e.description ? ` · ${e.description}` : ''}</div>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-display font-semibold text-rose-600">{fmt(e.amount)}</span>
              <button onClick={() => remove(e.id)} className="text-slate-300 hover:text-rose-600"><Trash2 size={15} /></button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
