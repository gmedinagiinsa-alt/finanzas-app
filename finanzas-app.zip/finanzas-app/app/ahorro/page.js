'use client';
import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { fmt } from '@/lib/constants';
import { Card } from '@/components/ui';

export default function AhorroPage() {
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('settings').select('*').eq('id', 'default').single();
      setSettings(data);
      setLoading(false);
    }
    load();
  }, []);

  async function updateField(patch) {
    const next = { ...settings, ...patch };
    setSettings(next);
    setSaving(true);
    await supabase.from('settings').update(patch).eq('id', 'default');
    setSaving(false);
  }

  const plannedSavings = useMemo(() => {
    if (!settings) return 0;
    if (settings.mode === 'fixed') return Math.min(Number(settings.fixed_amount) || 0, Number(settings.salary) || 0);
    return (Number(settings.salary) || 0) * ((Number(settings.percent) || 0) / 100);
  }, [settings]);

  const disponible = (Number(settings?.salary) || 0) - plannedSavings;

  if (loading) return <p className="text-sm text-slate-400 text-center py-16">Cargando…</p>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display font-bold text-2xl text-slate-900">Plan de ahorro</h1>
        <p className="text-sm text-slate-500 mt-1">Define tu sueldo y cuánto quieres apartar cada mes. {saving && '· guardando…'}</p>
      </div>

      <Card className="space-y-5">
        <div>
          <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Sueldo mensual</label>
          <div className="mt-1 flex items-center border border-slate-200 rounded-xl px-3 py-2.5 focus-within:border-indigo-400">
            <span className="text-slate-400 mr-1">$</span>
            <input
              type="number"
              value={settings.salary}
              onChange={e => updateField({ salary: Number(e.target.value) || 0 })}
              className="w-full outline-none font-display font-semibold text-lg"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Modo de ahorro</label>
          <div className="mt-2 flex gap-2">
            <button
              onClick={() => updateField({ mode: 'percent' })}
              className={`flex-1 py-2.5 rounded-xl text-sm font-medium border ${settings.mode === 'percent' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-500'}`}
            >
              Porcentaje
            </button>
            <button
              onClick={() => updateField({ mode: 'fixed' })}
              className={`flex-1 py-2.5 rounded-xl text-sm font-medium border ${settings.mode === 'fixed' ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-200 text-slate-500'}`}
            >
              Cantidad fija
            </button>
          </div>
        </div>

        {settings.mode === 'percent' ? (
          <div>
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Porcentaje del sueldo</label>
            <div className="mt-1 flex items-center border border-slate-200 rounded-xl px-3 py-2.5 focus-within:border-indigo-400">
              <input
                type="number"
                value={settings.percent}
                onChange={e => updateField({ percent: Number(e.target.value) || 0 })}
                className="w-full outline-none font-display font-semibold text-lg"
              />
              <span className="text-slate-400 ml-1">%</span>
            </div>
          </div>
        ) : (
          <div>
            <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Cantidad fija mensual</label>
            <div className="mt-1 flex items-center border border-slate-200 rounded-xl px-3 py-2.5 focus-within:border-indigo-400">
              <span className="text-slate-400 mr-1">$</span>
              <input
                type="number"
                value={settings.fixed_amount}
                onChange={e => updateField({ fixed_amount: Number(e.target.value) || 0 })}
                className="w-full outline-none font-display font-semibold text-lg"
              />
            </div>
          </div>
        )}
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">Ahorro programado</span>
          <div className="font-display font-bold text-xl text-indigo-600 mt-1">{fmt(plannedSavings)}</div>
        </Card>
        <Card>
          <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">Te queda disponible</span>
          <div className="font-display font-bold text-xl text-emerald-600 mt-1">{fmt(disponible)}</div>
        </Card>
      </div>
    </div>
  );
}
