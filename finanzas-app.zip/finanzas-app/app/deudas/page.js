'use client';
import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Pencil, X } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { fmt } from '@/lib/constants';
import { Card, Input } from '@/components/ui';

function emptyDebt() {
  return { bank: '', limit_amount: '', balance: '', min_payment: '', cut_date: '', due_date: '', interest_rate: '' };
}

export default function DeudasPage() {
  const [debts, setDebts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyDebt());

  async function load() {
    const { data } = await supabase.from('debts').select('*').order('created_at', { ascending: false });
    setDebts(data || []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  function openNew() { setForm(emptyDebt()); setEditingId(null); setShowForm(true); }
  function openEdit(d) { setForm(d); setEditingId(d.id); setShowForm(true); }

  async function submit() {
    if (!form.bank) return;
    if (editingId) {
      await supabase.from('debts').update(form).eq('id', editingId);
    } else {
      const { id, ...rest } = form;
      await supabase.from('debts').insert(rest);
    }
    setShowForm(false);
    load();
  }

  async function remove(id) {
    await supabase.from('debts').delete().eq('id', id);
    load();
  }

  const totalDebt = debts.reduce((s, d) => s + (Number(d.balance) || 0), 0);

  if (loading) return <p className="text-sm text-slate-400 text-center py-16">Cargando…</p>;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl text-slate-900">Deudas</h1>
          <p className="text-sm text-slate-500 mt-1">Total: <span className="text-rose-600 font-semibold">{fmt(totalDebt)}</span></p>
        </div>
        <button onClick={openNew} className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
          <Plus size={20} />
        </button>
      </div>

      {showForm && (
        <Card className="space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="font-display font-semibold">{editingId ? 'Editar tarjeta' : 'Nueva tarjeta'}</h3>
            <button onClick={() => setShowForm(false)}><X size={18} className="text-slate-400" /></button>
          </div>
          <Input label="Banco" value={form.bank} onChange={v => setForm({ ...form, bank: v })} />
          <div className="grid grid-cols-2 gap-3">
            <Input label="Límite de crédito" type="number" value={form.limit_amount} onChange={v => setForm({ ...form, limit_amount: v })} />
            <Input label="Saldo actual" type="number" value={form.balance} onChange={v => setForm({ ...form, balance: v })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Pago mínimo" type="number" value={form.min_payment} onChange={v => setForm({ ...form, min_payment: v })} />
            <Input label="Tasa de interés % (opcional)" type="number" value={form.interest_rate} onChange={v => setForm({ ...form, interest_rate: v })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Fecha de corte" type="date" value={form.cut_date} onChange={v => setForm({ ...form, cut_date: v })} />
            <Input label="Fecha límite de pago" type="date" value={form.due_date} onChange={v => setForm({ ...form, due_date: v })} />
          </div>
          <button onClick={submit} className="w-full py-2.5 rounded-xl bg-indigo-600 text-white text-sm font-medium mt-2">
            {editingId ? 'Guardar cambios' : 'Agregar tarjeta'}
          </button>
        </Card>
      )}

      <div className="space-y-3">
        {debts.length === 0 && <p className="text-sm text-slate-400 text-center py-8">Aún no has agregado tarjetas.</p>}
        {debts.map(d => (
          <Card key={d.id}>
            <div className="flex items-start justify-between">
              <div>
                <div className="font-display font-semibold text-slate-900">{d.bank}</div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Corte: {d.cut_date || '—'} · Límite de pago: {d.due_date || '—'}
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => openEdit(d)} className="text-slate-400 hover:text-indigo-600"><Pencil size={16} /></button>
                <button onClick={() => remove(d.id)} className="text-slate-400 hover:text-rose-600"><Trash2 size={16} /></button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-3 text-sm">
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Saldo</div>
                <div className="font-semibold text-rose-600">{fmt(d.balance)}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Límite</div>
                <div className="font-semibold">{fmt(d.limit_amount)}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Pago mín.</div>
                <div className="font-semibold">{fmt(d.min_payment)}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
