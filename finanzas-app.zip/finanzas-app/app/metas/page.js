'use client';
import React, { useState, useEffect } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { fmt } from '@/lib/constants';
import { Card, Input } from '@/components/ui';

export default function MetasPage() {
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', target_amount: '', current_amount: '' });

  async function load() {
    const { data } = await supabase.from('goals').select('*').order('created_at', { ascending: false });
    setGoals(data || []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function submit() {
    if (!form.name || !form.target_amount) return;
    await supabase.from('goals').insert(form);
    setForm({ name: '', target_amount: '', current_amount: '' });
    setShowForm(false);
    load();
  }

  async function remove(id) {
    await supabase.from('goals').delete().eq('id', id);
    load();
  }

  async function updateCurrent(id, value) {
    await supabase.from('goals').update({ current_amount: value }).eq('id', id);
    load();
  }

  if (loading) return <p className="text-sm text-slate-400 text-center py-16">Cargando…</p>;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl text-slate-900">Metas</h1>
          <p className="text-sm text-slate-500 mt-1">Fondo de emergencia, enganche, vacaciones, auto…</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
          <Plus size={20} />
        </button>
      </div>

      {showForm && (
        <Card className="space-y-3">
          <Input label="Nombre de la meta" value={form.name} onChange={v => setForm({ ...form, name: v })} />
          <div className="grid grid-cols-2 gap-3">
            <Input label="Monto objetivo" type="number" value={form.target_amount} onChange={v => setForm({ ...form, target_amount: v })} />
            <Input label="Ya llevas" type="number" value={form.current_amount} onChange={v => setForm({ ...form, current_amount: v })} />
          </div>
          <button onClick={submit} className="w-full py-2.5 rounded-xl bg-indigo-600 text-white text-sm font-medium">Crear meta</button>
        </Card>
      )}

      <div className="space-y-3">
        {goals.length === 0 && <p className="text-sm text-slate-400 text-center py-8">Aún no has creado metas.</p>}
        {goals.map(g => {
          const pct = Math.min(100, ((Number(g.current_amount) || 0) / (Number(g.target_amount) || 1)) * 100);
          return (
            <Card key={g.id}>
              <div className="flex items-start justify-between">
                <div className="font-display font-semibold text-slate-900">{g.name}</div>
                <button onClick={() => remove(g.id)} className="text-slate-300 hover:text-rose-600"><Trash2 size={15} /></button>
              </div>
              <div className="text-xs text-slate-400 mt-0.5 mb-3">{fmt(g.current_amount)} de {fmt(g.target_amount)}</div>
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 rounded-full" style={{ width: `${pct}%` }} />
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs font-medium text-slate-500">{pct.toFixed(0)}% completado</span>
                <input
                  type="number"
                  placeholder="Actualizar"
                  onKeyDown={e => {
                    if (e.key === 'Enter' && e.target.value) {
                      updateCurrent(g.id, Number(e.target.value));
                      e.target.value = '';
                    }
                  }}
                  className="w-24 text-xs border border-slate-200 rounded-lg px-2 py-1 outline-none focus:border-indigo-400"
                />
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
