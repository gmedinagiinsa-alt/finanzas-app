'use client';
import React, { useState, useEffect, useMemo } from 'react';
import { Wallet, TrendingUp, PiggyBank, CreditCard } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { supabase } from '@/lib/supabaseClient';
import { MONTHS, YEAR, fmt } from '@/lib/constants';
import { Card } from '@/components/ui';

export default function DashboardPage() {
  const [settings, setSettings] = useState(null);
  const [debts, setDebts] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [savingsActual, setSavingsActual] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [{ data: s }, { data: d }, { data: e }, { data: sa }] = await Promise.all([
        supabase.from('settings').select('*').eq('id', 'default').single(),
        supabase.from('debts').select('*'),
        supabase.from('expenses').select('*'),
        supabase.from('savings_actual').select('*'),
      ]);
      setSettings(s);
      setDebts(d || []);
      setExpenses(e || []);
      const saMap = {};
      (sa || []).forEach(row => { saMap[row.month_key] = row.amount; });
      setSavingsActual(saMap);
      setLoading(false);
    }
    load();
  }, []);

  const plannedSavings = useMemo(() => {
    if (!settings) return 0;
    if (settings.mode === 'fixed') return Math.min(Number(settings.fixed_amount) || 0, Number(settings.salary) || 0);
    return (Number(settings.salary) || 0) * ((Number(settings.percent) || 0) / 100);
  }, [settings]);

  const totalDebt = useMemo(() => debts.reduce((s, d) => s + (Number(d.balance) || 0), 0), [debts]);

  const currentMonthIdx = new Date().getMonth();
  const expensesThisMonth = useMemo(() => {
    return expenses
      .filter(e => {
        const d = new Date(e.date);
        return d.getFullYear() === YEAR && d.getMonth() === currentMonthIdx;
      })
      .reduce((s, e) => s + (Number(e.amount) || 0), 0);
  }, [expenses, currentMonthIdx]);

  const disponible = (Number(settings?.salary) || 0) - plannedSavings - expensesThisMonth;

  const totalSaved = useMemo(
    () => Object.values(savingsActual).reduce((s, v) => s + (Number(v) || 0), 0),
    [savingsActual]
  );

  const chartData = useMemo(() => {
    let cumulative = 0;
    return MONTHS.map((m, i) => {
      cumulative += Number(savingsActual[`${YEAR}-${i}`]) || 0;
      return { mes: m.slice(0, 3), ahorro: cumulative };
    });
  }, [savingsActual]);

  if (loading) return <p className="text-sm text-slate-400 text-center py-16">Cargando…</p>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display font-bold text-2xl text-slate-900">Hola 👋</h1>
        <p className="text-sm text-slate-500 mt-1">Este es el resumen de tus finanzas.</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard label="Sueldo mensual" value={settings?.salary} accent={{ bg: 'bg-indigo-50', text: 'text-indigo-600' }} icon={Wallet} />
        <StatCard label="Disponible" value={disponible} accent={{ bg: 'bg-emerald-50', text: 'text-emerald-600' }} icon={TrendingUp} />
        <StatCard label="Ahorrado" value={totalSaved} accent={{ bg: 'bg-amber-50', text: 'text-amber-600' }} icon={PiggyBank} />
        <StatCard label="Deudas totales" value={totalDebt} accent={{ bg: 'bg-rose-50', text: 'text-rose-600' }} icon={CreditCard} />
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-semibold text-slate-900">Avance de ahorro {YEAR}</h2>
          <span className="text-xs text-slate-400">Meta mensual: {fmt(plannedSavings)}</span>
        </div>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef0f3" />
              <XAxis dataKey="mes" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={v => `${Math.round(v / 1000)}k`} />
              <Tooltip formatter={v => fmt(v)} contentStyle={{ borderRadius: 12, border: '1px solid #eef0f3', fontSize: 12 }} />
              <Line type="monotone" dataKey="ahorro" stroke="#4f46e5" strokeWidth={2.5} dot={{ r: 3, fill: '#4f46e5' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}

function StatCard({ label, value, accent, icon: Icon }) {
  return (
    <Card>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">{label}</span>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${accent.bg}`}>
          <Icon size={15} className={accent.text} />
        </div>
      </div>
      <div className="font-display font-bold text-2xl text-slate-900">{fmt(value)}</div>
    </Card>
  );
}
